from __future__ import unicode_literals

from django.apps import AppConfig


class Belt2Config(AppConfig):
    name = 'belt2'
